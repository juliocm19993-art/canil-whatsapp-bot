import { supabase } from "../../../src/lib/supabase";

export async function GET() {
  const { data, error } = await supabase
    .from("informacoes_canil")
    .select("*")
    .order("criado_em", { ascending: false });

  if (error) {
    console.log("Erro GET informacoes:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }

  return Response.json(data || []);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    console.log("Recebido no POST:", body);

    const { titulo, categoria, conteudo } = body;

    const { data, error } = await supabase
      .from("informacoes_canil")
      .insert({
        titulo,
        categoria,
        conteudo,
        ativo: true,
      })
      .select()
      .single();

    if (error) {
      console.log("Erro POST informacoes:", error.message);
      return Response.json({ error: error.message }, { status: 500 });
    }

    console.log("Informação salva:", data);

    return Response.json(data);
  } catch (error) {
    console.log("Erro geral POST:", error);
    return Response.json({ error: "Erro interno" }, { status: 500 });
  }
}