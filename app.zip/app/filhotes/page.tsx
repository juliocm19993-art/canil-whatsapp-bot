"use client";

import { useEffect, useState } from "react";

export default function FilhotesPage() {
  const [filhotes, setFilhotes] = useState<any[]>([]);
  const [salvando, setSalvando] = useState(false);
  const [enviando, setEnviando] = useState(false);

  const [form, setForm] = useState({
    nome: "",
    sexo: "",
    cor: "",
    data_nascimento: "",
    data_disponivel: "",
    valor: "",
    descricao: "",
    foto_url: "",
    fotos: [] as string[],
    videos: [] as string[],
    status: "disponivel",
  });

  async function carregar() {
    const res = await fetch("/api/filhotes");
    const data = await res.json();
    setFilhotes(data);
  }

  async function uploadArquivos(files: FileList | null, tipo: "fotos" | "videos") {
    if (!files || files.length === 0) return;

    setEnviando(true);

    const formData = new FormData();

    Array.from(files).forEach((file) => {
      formData.append("arquivos", file);
    });

    const res = await fetch("/api/upload", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();

    if (data.urls) {
      setForm((prev) => ({
        ...prev,
        [tipo]: data.urls,
        foto_url: tipo === "fotos" ? data.urls[0] || "" : prev.foto_url,
      }));
    }

    setEnviando(false);
  }

  async function salvar(e: React.FormEvent) {
    e.preventDefault();

    setSalvando(true);

    await fetch("/api/filhotes", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(form),
    });

    setForm({
      nome: "",
      sexo: "",
      cor: "",
      data_nascimento: "",
      data_disponivel: "",
      valor: "",
      descricao: "",
      foto_url: "",
      fotos: [],
      videos: [],
      status: "disponivel",
    });

    setSalvando(false);
    carregar();
  }

  useEffect(() => {
    carregar();
  }, []);

  return (
    <main style={{ padding: 30, fontFamily: "Arial", background: "#f5f5f5", minHeight: "100vh" }}>
      <h1>Catálogo de Filhotes 🐶</h1>

      <form onSubmit={salvar} style={{ background: "white", padding: 20, borderRadius: 10, display: "grid", gap: 12, maxWidth: 700 }}>
        <input placeholder="Nome ou identificação" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} />
        <input placeholder="Sexo: macho ou fêmea" value={form.sexo} onChange={(e) => setForm({ ...form, sexo: e.target.value })} />
        <input placeholder="Cor" value={form.cor} onChange={(e) => setForm({ ...form, cor: e.target.value })} />
        <input type="date" value={form.data_nascimento} onChange={(e) => setForm({ ...form, data_nascimento: e.target.value })} />
        <input type="date" value={form.data_disponivel} onChange={(e) => setForm({ ...form, data_disponivel: e.target.value })} />
        <input placeholder="Valor" value={form.valor} onChange={(e) => setForm({ ...form, valor: e.target.value })} />

        <textarea placeholder="Descrição do filhote" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} rows={4} />

        <div>
          <strong>Fotos</strong>
          <input type="file" multiple accept="image/*" onChange={(e) => uploadArquivos(e.target.files, "fotos")} />
          <p>{form.fotos.length} foto(s) enviada(s)</p>
        </div>

        <div>
          <strong>Vídeos</strong>
          <input type="file" multiple accept="video/*" onChange={(e) => uploadArquivos(e.target.files, "videos")} />
          <p>{form.videos.length} vídeo(s) enviado(s)</p>
        </div>

        {enviando && <p>Enviando arquivos...</p>}

        <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
          <option value="disponivel">Disponível</option>
          <option value="reservado">Reservado</option>
          <option value="vendido">Vendido</option>
          <option value="indisponivel">Indisponível</option>
        </select>

        <button type="submit" disabled={salvando || enviando}>
          {salvando ? "Salvando..." : "Salvar filhote"}
        </button>
      </form>

      <section style={{ marginTop: 30 }}>
        <h2>Filhotes cadastrados</h2>

        {filhotes.map((f) => (
          <div key={f.id} style={{ background: "white", padding: 20, borderRadius: 10, marginBottom: 15 }}>
            <h3>{f.nome || "Filhote"}</h3>
            <p><strong>Sexo:</strong> {f.sexo}</p>
            <p><strong>Cor:</strong> {f.cor}</p>
            <p><strong>Disponível em:</strong> {f.data_disponivel}</p>
            <p><strong>Valor:</strong> {f.valor ? `R$ ${f.valor}` : "Não informado"}</p>
            <p><strong>Status:</strong> {f.status}</p>
            <p>{f.descricao}</p>

            {f.fotos?.length > 0 && (
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                {f.fotos.map((foto: string) => (
                  <img key={foto} src={foto} style={{ width: 120, height: 120, objectFit: "cover", borderRadius: 10 }} />
                ))}
              </div>
            )}

            {f.videos?.length > 0 && (
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 10 }}>
                {f.videos.map((video: string) => (
                  <video key={video} src={video} controls style={{ width: 180, borderRadius: 10 }} />
                ))}
              </div>
            )}
          </div>
        ))}
      </section>
    </main>
  );
}