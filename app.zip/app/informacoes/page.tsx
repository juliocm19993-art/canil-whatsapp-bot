"use client";

import { useEffect, useState } from "react";

export default function InformacoesPage() {
  const [titulo, setTitulo] = useState("");
  const [categoria, setCategoria] = useState("");
  const [conteudo, setConteudo] = useState("");
  const [informacoes, setInformacoes] = useState<any[]>([]);
  const [salvando, setSalvando] = useState(false);

  async function carregarInformacoes() {
    const res = await fetch("/api/informacoes");
    const data = await res.json();
    setInformacoes(data);
  }

  async function salvarInformacao(e: React.FormEvent) {
    e.preventDefault();

    setSalvando(true);

    await fetch("/api/informacoes", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        titulo,
        categoria,
        conteudo,
      }),
    });

    setTitulo("");
    setCategoria("");
    setConteudo("");
    setSalvando(false);

    carregarInformacoes();
  }

  useEffect(() => {
    carregarInformacoes();
  }, []);

  return (
    <main
      style={{
        padding: 30,
        fontFamily: "Arial",
        background: "#f5f5f5",
        minHeight: "100vh",
      }}
    >
      <h1>Informações da IA 🧠🐶</h1>

      <p>
        Cadastre aqui informações que a IA pode usar para responder os clientes.
      </p>

      <form
        onSubmit={salvarInformacao}
        style={{
          background: "white",
          padding: 20,
          borderRadius: 10,
          display: "grid",
          gap: 15,
          maxWidth: 700,
          marginTop: 20,
        }}
      >
        <input
          placeholder="Título. Ex: Próxima ninhada"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          style={{
            padding: 12,
            borderRadius: 8,
            border: "1px solid #ccc",
          }}
        />

        <input
          placeholder="Categoria. Ex: filhotes, valores, entrega, vacinas"
          value={categoria}
          onChange={(e) => setCategoria(e.target.value)}
          style={{
            padding: 12,
            borderRadius: 8,
            border: "1px solid #ccc",
          }}
        />

        <textarea
          placeholder="Conteúdo que a IA deve saber"
          value={conteudo}
          onChange={(e) => setConteudo(e.target.value)}
          rows={6}
          style={{
            padding: 12,
            borderRadius: 8,
            border: "1px solid #ccc",
          }}
        />

        <button
          type="submit"
          disabled={salvando}
          style={{
            padding: 14,
            borderRadius: 8,
            border: "none",
            background: "#0f766e",
            color: "white",
            cursor: "pointer",
            fontWeight: "bold",
          }}
        >
          {salvando ? "Salvando..." : "Salvar informação"}
        </button>
      </form>

      <section style={{ marginTop: 30 }}>
        <h2>Informações cadastradas</h2>

        {informacoes.map((info) => (
          <div
            key={info.id}
            style={{
              background: "white",
              padding: 20,
              borderRadius: 10,
              marginBottom: 15,
            }}
          >
            <h3>{info.titulo}</h3>
            <p>
              <strong>Categoria:</strong> {info.categoria || "geral"}
            </p>
            <p>{info.conteudo}</p>
          </div>
        ))}
      </section>
    </main>
  );
}