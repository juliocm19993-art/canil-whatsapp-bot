import { supabase } from "../../../src/lib/supabase";

export async function GET() {
  const { data, error } = await supabase
    .from("filhotes_catalogo")
    .select("*")
    .order("criado_em", { ascending: false });

  if (error) {
    console.log("Erro GET filhotes:", error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }

  return Response.json(data || []);
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    console.log("Recebido no POST filhotes:", body);

    const { data, error } = await supabase
      .from("filhotes_catalogo")
      .insert({
        nome: body.nome || null,
        sexo: body.sexo || null,
        cor: body.cor || null,
        data_nascimento: body.data_nascimento || null,
        data_disponivel: body.data_disponivel || null,
        valor: body.valor ? Number(body.valor) : null,
        descricao: body.descricao || null,
        foto_url: body.foto_url || null,
        fotos: body.fotos || [],
        videos: body.videos || [],
        status: body.status || "disponivel",
      })
      .select()
      .single();

    if (error) {
      console.log("Erro POST filhotes:", error.message);
      return Response.json({ error: error.message }, { status: 500 });
    }

    console.log("Filhote salvo:", data);

    return Response.json(data);
  } catch (error) {
    console.log("Erro geral POST filhotes:", error);
    return Response.json({ error: "Erro interno" }, { status: 500 });
  }
}