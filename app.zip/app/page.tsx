async function getClientes() {
  const res = await fetch("http://localhost:3000/api/clientes", {
    cache: "no-store",
  });
  return res.json();
}

async function getMensagens() {
  const res = await fetch("http://localhost:3000/api/mensagens", {
    cache: "no-store",
  });
  return res.json();
}

export default async function Home() {
  const clientes = await getClientes();
  const mensagens = await getMensagens();

  const clienteSelecionado = clientes[0];
  const mensagensCliente = mensagens
    .filter((msg: any) => msg.telefone === clienteSelecionado?.telefone)
    .reverse();

  return (
    <main style={{ display: "flex", height: "100vh", fontFamily: "Arial" }}>
      <aside style={{ width: 320, borderRight: "1px solid #ddd", padding: 20 }}>
        <h2>🐶 Clientes</h2>

        {clientes.map((cliente: any) => (
          <div
            key={cliente.id}
            style={{
              padding: 12,
              borderBottom: "1px solid #eee",
              cursor: "pointer",
            }}
          >
            {cliente.telefone}
          </div>
        ))}
      </aside>

      <section style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <header style={{ padding: 20, borderBottom: "1px solid #ddd" }}>
          <h2>{clienteSelecionado?.telefone || "Nenhum cliente"}</h2>
        </header>

        <div style={{ flex: 1, padding: 20, background: "#f5f5f5" }}>
          {mensagensCliente.map((msg: any) => (
            <div
              key={msg.id}
              style={{
                display: "flex",
                justifyContent:
                  msg.direcao === "enviada" ? "flex-end" : "flex-start",
                marginBottom: 10,
              }}
            >
              <div
                style={{
                  background: msg.direcao === "enviada" ? "#dcf8c6" : "white",
                  padding: 12,
                  borderRadius: 10,
                  maxWidth: "60%",
                }}
              >
                {msg.mensagem}
              </div>
            </div>
          ))}
        </div>

        <footer style={{ padding: 20, borderTop: "1px solid #ddd" }}>
          <input
            placeholder="Em breve: responder manualmente..."
            disabled
            style={{
              width: "100%",
              padding: 14,
              borderRadius: 8,
              border: "1px solid #ccc",
            }}
          />
        </footer>
      </section>
    </main>
  );
}